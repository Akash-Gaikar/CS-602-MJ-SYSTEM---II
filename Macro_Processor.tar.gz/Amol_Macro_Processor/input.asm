; Amol's original macro examples

%macro myincrement 2
    mov eax, %1
    add eax, %2
    mov %1, eax
%endmacro

%macro mydecrement 2
    mov eax, %1
    sub eax, %2
    mov %1, eax
%endmacro

%macro mydouble 2
    mov eax, %1
    add eax, %1
    mov %2, eax
%endmacro

%macro mycopy 2
    mov %2, %1
%endmacro

%macro myclear 1
    mov %1, 0
%endmacro

section .text
global main

main:
    myincrement eax, 5
    mydecrement ebx, 2
    mydouble ecx, edx
    mycopy eax, esi
    myclear edi
    ret
