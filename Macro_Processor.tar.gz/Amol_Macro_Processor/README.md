# Macro Processor Practical

**Title:** Creating and Expanding Assembly Language Macros  
**Author:** Amol Rajendra Barde  
**Course:** Systems Programming / Systems-II  
**Language:** C++  
**Environment:** Ubuntu Linux, GCC

## Aim
To create a simple macro processor in C++ that reads macro definitions and macro calls from an assembly-style input file, substitutes parameters, and writes the expanded instructions to an output file.

## Original macros in this project

| Macro | Parameters | Purpose |
|---|---:|---|
| `myincrement` | 2 | Adds a value to a register |
| `mydecrement` | 2 | Subtracts a value from a register |
| `mydouble` | 2 | Doubles the first register's value and stores it in the second register |
| `mycopy` | 2 | Copies one register value to another |
| `myclear` | 1 | Sets a register to zero |

## Files

- `macro_processor.cpp` — C++ implementation of the macro processor.
- `input.asm` — Macro definitions and calls used for testing.
- `README.md` — Project description and instructions.
- `output.asm` — Generated after running the program; it is not required to be committed.

## Compile

```bash
g++ -std=c++11 -Wall -Wextra macro_processor.cpp -o macro_processor
```

## Run

```bash
./macro_processor input.asm output.asm
```

## View expanded output

```bash
cat output.asm
```

The program should print:

```text
Macro expansion completed successfully!
Output file: output.asm
```

## How it works

1. The program reads `input.asm` line by line.
2. When it finds `%macro`, it stores the macro name, parameter count, and body instructions in a macro table.
3. When it finds `%endmacro`, it finishes storing that macro.
4. When it finds a macro call, it reads the arguments and replaces `%1`, `%2`, and so on with the supplied values.
5. It writes the expanded instructions and the remaining assembly lines to `output.asm`.

## Important note

This is an educational macro-expansion program. It expands the assembly-style macro syntax into text; it does not assemble or execute the resulting assembly program. The syntax in `input.asm` is NASM-style. The C++ program itself performs the macro expansion.
