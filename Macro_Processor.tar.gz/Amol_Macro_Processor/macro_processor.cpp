#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <cctype>

using namespace std;

struct Macro {
    string name;
    int parameterCount;
    vector<string> instructions;
};

map<string, Macro> macroTable;

string trim(const string& text) {
    size_t first = text.find_first_not_of(" \t\r\n");
    if (first == string::npos) return "";
    size_t last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

vector<string> splitArguments(const string& text) {
    vector<string> args;
    string item;
    stringstream input(text);
    while (getline(input, item, ',')) args.push_back(trim(item));
    if (args.size() == 1 && args[0].empty()) args.clear();
    return args;
}

string substituteParameters(const string& line, const vector<string>& args) {
    string result;
    for (size_t i = 0; i < line.size();) {
        if (line[i] == '%' && i + 1 < line.size() &&
            isdigit(static_cast<unsigned char>(line[i + 1]))) {
            size_t j = i + 1;
            int number = 0;
            while (j < line.size() && isdigit(static_cast<unsigned char>(line[j]))) {
                number = number * 10 + (line[j] - '0');
                ++j;
            }
            if (number >= 1 && static_cast<size_t>(number) <= args.size())
                result += args[number - 1];
            else
                result += line.substr(i, j - i);
            i = j;
        } else {
            result += line[i];
            ++i;
        }
    }
    return result;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: ./macro_processor input.asm output.asm\n";
        return 1;
    }

    ifstream input(argv[1]);
    if (!input) {
        cerr << "Error: cannot open input file: " << argv[1] << '\n';
        return 1;
    }

    ofstream output(argv[2]);
    if (!output) {
        cerr << "Error: cannot create output file: " << argv[2] << '\n';
        return 1;
    }

    string line;
    Macro* activeMacro = NULL;
    int lineNumber = 0;

    while (getline(input, line)) {
        ++lineNumber;
        string cleaned = trim(line);

        if (cleaned.empty() || cleaned[0] == ';') {
            if (activeMacro != NULL) activeMacro->instructions.push_back(line);
            else output << line << '\n';
            continue;
        }

        if (cleaned.compare(0, 6, "%macro") == 0) {
            if (activeMacro != NULL) {
                cerr << "Error on line " << lineNumber << ": nested macro definitions are not supported.\n";
                return 1;
            }
            string keyword, name;
            int count;
            stringstream parser(cleaned);
            if (!(parser >> keyword >> name >> count) || count < 0) {
                cerr << "Error on line " << lineNumber << ": invalid macro definition.\n";
                return 1;
            }
            Macro fresh;
            fresh.name = name;
            fresh.parameterCount = count;
            macroTable[name] = fresh;
            activeMacro = &macroTable[name];
            continue;
        }

        if (cleaned == "%endmacro") {
            if (activeMacro == NULL) {
                cerr << "Error on line " << lineNumber << ": %endmacro without %macro.\n";
                return 1;
            }
            activeMacro = NULL;
            continue;
        }

        if (activeMacro != NULL) {
            activeMacro->instructions.push_back(line);
            continue;
        }

        stringstream parser(cleaned);
        string calledName;
        parser >> calledName;
        map<string, Macro>::iterator found = macroTable.find(calledName);

        if (found == macroTable.end()) {
            output << line << '\n';
            continue;
        }

        string remaining;
        getline(parser, remaining);
        vector<string> args = splitArguments(trim(remaining));
        Macro& macro = found->second;

        if (static_cast<int>(args.size()) != macro.parameterCount) {
            cerr << "Error on line " << lineNumber << ": macro '" << calledName
                 << "' expects " << macro.parameterCount << " argument(s), but received "
                 << args.size() << ".\n";
            return 1;
        }

        for (size_t i = 0; i < macro.instructions.size(); ++i)
            output << substituteParameters(macro.instructions[i], args) << '\n';
    }

    if (activeMacro != NULL) {
        cerr << "Error: macro '" << activeMacro->name << "' is missing %endmacro.\n";
        return 1;
    }

    cout << "Macro expansion completed successfully!\n";
    cout << "Output file: " << argv[2] << '\n';
    return 0;
}
